import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { framesOf, inr, type Relic } from "@/data/catalog";
import { nozzles } from "@/data/nozzles";
import { useCart } from "@/lib/cart";

export function SiteHeader() {
  const { count } = useCart();
  return (
    <header className="gold-plate sticky top-0 z-20">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-3 py-2 sm:px-6">
        <Link to="/" className="flex min-w-0 items-center">
          <img src="/mud-relics-logo.png" alt="MUD RELICS" className="brand-mark h-11 w-auto sm:h-16" />
        </Link>
        <Link to="/cart" className="cart-link inline-flex min-h-11 shrink-0 items-center font-mono text-xs font-medium tracking-widest">
          CART{count > 0 ? ` · ${count}` : ""}
        </Link>
      </div>
    </header>
  );
}

function wrap(angle: number) {
  let value = ((angle % 360) + 360) % 360;
  if (value > 180) value -= 360;
  return value;
}

export function Roll({ relics }: { relics: Relic[] }) {
  const navigate = useNavigate();
  const count = relics.length;
  const angle = useRef(0);
  const target = useRef(0);
  const idle = useRef(0);
  const drag = useRef<{ x: number; a: number } | null>(null);
  const moved = useRef(false);
  const [shown, setShown] = useState(0);
  const [wide, setWide] = useState(false);

  useEffect(() => {
    const query = window.matchMedia("(min-width: 640px)");
    const sync = () => setWide(query.matches);
    sync();
    query.addEventListener("change", sync);
    return () => query.removeEventListener("change", sync);
  }, []);

  const size = wide ? 220 : 148;
  const step = 360 / count;

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let frame = 0;
    let then = performance.now();
    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - then) / 1000);
      then = now;
      if (!drag.current) {
        idle.current += dt;
        if (idle.current > 2.6) {
          idle.current = 0;
          target.current += step;
        }
        const delta = wrap(target.current - angle.current);
        angle.current += delta * Math.min(1, dt * 3);
        setShown(angle.current);
      }
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [step]);

  const index = (Math.round(-shown / step) % count + count) % count;
  const front = relics[index];

  return (
    <section className="relative overflow-hidden">
      <div
        className="relative h-[28rem] touch-none select-none sm:h-[36rem]"
        style={{ perspective: "1100px" }}
        onPointerDown={(event) => {
          moved.current = false;
          drag.current = { x: event.clientX, a: angle.current };
          event.currentTarget.setPointerCapture(event.pointerId);
        }}
        onPointerMove={(event) => {
          if (!drag.current) return;
          const dx = event.clientX - drag.current.x;
          if (Math.abs(dx) > 6) moved.current = true;
          angle.current = drag.current.a + dx * 0.28;
          target.current = angle.current;
          setShown(angle.current);
        }}
        onPointerUp={() => {
          drag.current = null;
          const snapped = Math.round(angle.current / step) * step;
          target.current = snapped;
          idle.current = 0;
        }}
        onPointerCancel={() => {
          drag.current = null;
        }}
      >
        <div className="absolute top-1/2 left-1/2 h-0 w-0" style={{ transformStyle: "preserve-3d" }}>
          {relics.map((relic, i) => {
            const place = wrap(i * step + shown) / step;
            const distance = Math.abs(place);
            const x = place * (wide ? size * 1.38 : size * 1.42);
            const rot = -place * 34;
            const z = -distance * 80;
            const scale = Math.max(0.62, 1 - distance * 0.24);
            return (
              <button
                key={relic.id}
                type="button"
                className="absolute top-0 left-0"
                style={{
                  width: size,
                  transform: `translateX(${x}px) translateZ(${z}px) rotateY(${rot}deg) scale(${scale}) translate(-50%, -50%)`,
                  transformStyle: "preserve-3d",
                  zIndex: Math.round(100 - distance * 10),
                  opacity: distance > 1.25 ? 0 : distance > 0.35 ? 0.8 : 1,
                  pointerEvents: distance > 0.45 ? "none" : "auto",
                }}
                onClick={() => {
                  if (!moved.current) navigate({ to: "/relics/$id", params: { id: relic.id } });
                }}
              >
                <img
                  src={relic.image}
                  alt={relic.name}
                  draggable={false}
                  className="relic-float aspect-[3/4] w-full object-contain"
                  style={{ animationDelay: `${i * 0.4}s` }}
                />
              </button>
            );
          })}
        </div>
      </div>
      <div className="pointer-events-none absolute inset-x-0 bottom-2 text-center">
        <p className="font-display text-3xl leading-none tracking-wide text-parchment sm:text-5xl">{front.name}</p>
        <p className="mt-2 font-mono text-xs tracking-widest text-gold">
          {front.number ? `${front.number} · ` : ""}
          {front.price != null ? `${inr(front.price)} · ` : ""}DRAG TO ROLL
        </p>
      </div>
    </section>
  );
}

export function RelicCard({ relic }: { relic: Relic }) {
  const status = relic.status === "AVAILABLE" ? "AVAILABLE" : relic.status;
  return (
    <Link to="/relics/$id" params={{ id: relic.id }} className="block bg-surface">
      <div className="flex aspect-square items-center justify-center bg-bg">
        <img src={relic.image} alt={relic.name} loading="lazy" decoding="async" className="h-[88%] w-[88%] object-contain" />
      </div>
      <div className="space-y-1 px-3 py-3">
        {relic.number ? <p className="font-mono text-xs tracking-widest text-gold">{relic.number}</p> : null}
        <h3 className="font-display text-2xl leading-none tracking-wide text-parchment">{relic.name}</h3>
        <div className="flex items-baseline justify-between gap-2 pt-1">
          <p className="font-mono text-xs text-gold">{relic.price != null ? inr(relic.price) : ""}</p>
          <p className="font-mono text-xs text-muted">{status}</p>
        </div>
      </div>
    </Link>
  );
}

export function Band({
  id,
  index,
  title,
  note,
  relics,
}: {
  id: string;
  index: string;
  title: string;
  note: string;
  relics: Relic[];
}) {
  return (
    <section id={id} className="archive-anchor mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <div className="on-swirl flex items-end justify-between gap-4 border-b border-forest pb-3">
        <div>
          <p className="font-mono text-xs tracking-widest text-gold">{index}</p>
          <h2 className="mt-2 font-serif text-3xl tracking-wide text-parchment sm:text-4xl">{title}</h2>
        </div>
        <p className="font-mono text-xs text-muted">{relics.length}</p>
      </div>
      <p className="on-swirl mt-3 max-w-md text-sm leading-relaxed text-fg">{note}</p>
      <ul className="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {relics.map((relic) => (
          <li key={relic.id}>
            <RelicCard relic={relic} />
          </li>
        ))}
      </ul>
    </section>
  );
}

export function Turner({ relic }: { relic: Relic }) {
  const frames = framesOf(relic);
  const many = frames.length > 1;
  const canIgnite = relic.kind === "lighter";
  const [index, setIndex] = useState(0);
  const [lit, setLit] = useState(false);
  const [flame, setFlame] = useState<{ left: number; top: number } | null>(null);
  const indexRef = useRef(0);
  const stageRef = useRef<HTMLDivElement>(null);
  const drag = useRef<{ x: number; y: number; locked: boolean | null } | null>(null);

  useEffect(() => {
    indexRef.current = 0;
    setIndex(0);
    setLit(false);
  }, [relic.id]);

  useEffect(() => {
    if (!many) return;
    for (const src of frames) {
      const img = new Image();
      img.src = src;
    }
  }, [many, frames]);

  useEffect(() => {
    const node = stageRef.current;
    if (!node || !many) return;
    let bank = 0;
    const onWheel = (event: WheelEvent) => {
      const dx = Math.abs(event.deltaX) > Math.abs(event.deltaY) ? event.deltaX : 0;
      if (!dx) return;
      event.preventDefault();
      bank += dx;
      const step = 48;
      const len = frames.length;
      while (Math.abs(bank) >= step) {
        const dir = bank > 0 ? 1 : -1;
        bank -= dir * step;
        indexRef.current = (indexRef.current - dir + len) % len;
        setIndex(indexRef.current);
      }
    };
    node.addEventListener("wheel", onWheel, { passive: false });
    return () => node.removeEventListener("wheel", onWheel);
  }, [many, frames]);

  useEffect(() => {
    if (!lit) {
      setFlame(null);
      return;
    }
    const place = () => {
      const stage = stageRef.current;
      const img = stage?.querySelector<HTMLImageElement>("img[data-live='1']");
      const tip = nozzles[frames[index]?.split("?")[0] ?? ""];
      if (!stage || !img || !tip) {
        setFlame(null);
        return;
      }
      if (!img.naturalWidth) {
        img.addEventListener("load", place, { once: true });
        return;
      }
      const box = stage.getBoundingClientRect();
      const scale = Math.min(box.width / img.naturalWidth, box.height / img.naturalHeight);
      const dw = img.naturalWidth * scale;
      const dh = img.naturalHeight * scale;
      setFlame({
        left: (box.width - dw) / 2 + tip.x * dw,
        top: (box.height - dh) / 2 + tip.y * dh,
      });
    };
    place();
    window.addEventListener("resize", place);
    return () => window.removeEventListener("resize", place);
  }, [lit, index, frames]);

  const show = (next: number) => {
    const len = frames.length;
    const wrapped = ((next % len) + len) % len;
    if (wrapped === indexRef.current) return;
    indexRef.current = wrapped;
    setIndex(wrapped);
  };

  return (
    <div>
      <div
        ref={stageRef}
        className={many ? "relative aspect-[3/4] w-full select-none bg-bg" : "relative aspect-[3/4] w-full bg-bg"}
        style={{ touchAction: many ? "pan-y" : undefined }}
        onPointerDown={(event) => {
          if (!many) return;
          drag.current = { x: event.clientX, y: event.clientY, locked: null };
        }}
        onPointerMove={(event) => {
          if (!drag.current || !many) return;
          const dx = event.clientX - drag.current.x;
          const dy = event.clientY - drag.current.y;
          if (drag.current.locked === null) {
            if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return;
            drag.current.locked = Math.abs(dx) > Math.abs(dy);
            if (!drag.current.locked) {
              drag.current = null;
              return;
            }
            drag.current.x = event.clientX;
            event.currentTarget.setPointerCapture(event.pointerId);
            event.currentTarget.style.touchAction = "none";
            return;
          }
          const step = Math.max(18, Math.min(40, 160 / frames.length));
          if (Math.abs(dx) < step) return;
          const direction = dx > 0 ? 1 : -1;
          drag.current.x += direction * step;
          show(indexRef.current - direction);
        }}
        onPointerUp={(event) => {
          drag.current = null;
          event.currentTarget.style.touchAction = many ? "pan-y" : "";
        }}
        onPointerCancel={(event) => {
          drag.current = null;
          event.currentTarget.style.touchAction = many ? "pan-y" : "";
        }}
      >
        {frames.map((src, frame) => (
          <img
            key={src + frame}
            src={src}
            alt={frame === index ? relic.name : ""}
            draggable={false}
            decoding="async"
            loading={frame === 0 ? "eager" : "lazy"}
            data-live={frame === index ? "1" : undefined}
            className="absolute inset-0 h-full w-full object-contain"
            style={{ opacity: frame === index ? 1 : 0 }}
          />
        ))}
        {lit && flame ? (
          <span className="nozzle-flame" style={{ left: flame.left, top: flame.top }} aria-hidden="true" />
        ) : null}
      </div>
      <p className="pb-2 pt-2 text-center font-mono text-xs tracking-widest text-muted">
        {many ? "DRAG TO INSPECT" : "ONE ANGLE"}
      </p>
      {canIgnite ? (
        <button
          type="button"
          aria-pressed={lit}
          onClick={() => setLit((on) => !on)}
          className="mx-auto mb-3 flex min-h-11 items-center px-4 font-mono text-xs tracking-widest text-gold"
        >
          {lit ? "EXTINGUISH" : "IGNITE"}
        </button>
      ) : null}
    </div>
  );
}
