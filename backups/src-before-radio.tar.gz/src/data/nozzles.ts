export const nozzles: Record<string, { x: number; y: number }> = {
  "/relics/black-tongue.png": {
    "x": 0.4274,
    "y": 0.0272
  },
  "/relics/yellow-screw.png": {
    "x": 0.4802,
    "y": 0.0217
  },
  "/relics/red-many.png": {
    "x": 0.4386,
    "y": 0.0298
  },
  "/relics/horn-eye.png": {
    "x": 0.5227,
    "y": 0.0
  },
  "/relics/green-mouth.png": {
    "x": 0.4298,
    "y": 0.0256
  },
  "/relics/eye-stack.png": {
    "x": 0.3541,
    "y": 0.0
  },
  "/relics/skull-pile.png": {
    "x": 0.0611,
    "y": 0.017
  },
  "/relics/pink-rock.png": {
    "x": 0.3735,
    "y": 0.0
  },
  "/relics/toxic-overgrowth.png": {
    "x": 0.3961,
    "y": 0.0284
  },
  "/relics/cosmic-carnage.png": {
    "x": 0.5306,
    "y": 0.0375
  },
  "/relics/ghostface.png": {
    "x": 0.4764,
    "y": 0.0293
  },
  "/relics/3-horned-sentinel/01-front.png": {
    "x": 0.4159,
    "y": 0.0212
  },
  "/relics/3-horned-sentinel/02-front.png": {
    "x": 0.4293,
    "y": 0.0211
  },
  "/relics/3-horned-sentinel/03-front.png": {
    "x": 0.2685,
    "y": 0.0635
  },
  "/relics/3-horned-sentinel/04-front.png": {
    "x": 0.5311,
    "y": 0.163
  },
  "/relics/3-horned-sentinel/05-side.png": {
    "x": 0.6609,
    "y": 0.0223
  },
  "/relics/3-horned-sentinel/06-back.png": {
    "x": 0.4367,
    "y": 0.024
  },
  "/relics/3-horned-sentinel/07-side.png": {
    "x": 0.3862,
    "y": 0.0221
  },
  "/relics/3-horned-sentinel/08-side.png": {
    "x": 0.4058,
    "y": 0.0221
  },
  "/relics/jade-bandit/01-front.png": {
    "x": 0.5945,
    "y": 0.0612
  },
  "/relics/jade-bandit/02-side.png": {
    "x": 0.657,
    "y": 0.0612
  },
  "/relics/jade-bandit/03-back.png": {
    "x": 0.3347,
    "y": 0.0612
  },
  "/relics/jade-bandit/04-side.png": {
    "x": 0.2522,
    "y": 0.0612
  },
  "/relics/jade-bandit/05-side.png": {
    "x": 0.2459,
    "y": 0.0612
  },
  "/relics/jade-bandit/06-front.png": {
    "x": 0.4472,
    "y": 0.0612
  },
  "/relics/mirror-mirror/01-side.png": {
    "x": 0.4327,
    "y": 0.0729
  },
  "/relics/mirror-mirror/02-side.png": {
    "x": 0.373,
    "y": 0.0729
  },
  "/relics/mirror-mirror/03-front.png": {
    "x": 0.4688,
    "y": 0.0729
  },
  "/relics/mirror-mirror/04-front.png": {
    "x": 0.4744,
    "y": 0.0729
  },
  "/relics/mirror-mirror/05-side.png": {
    "x": 0.4306,
    "y": 0.0729
  },
  "/relics/mirror-mirror/06-back.png": {
    "x": 0.6285,
    "y": 0.0729
  },
  "/relics/floral-trinity/01-front.png": {
    "x": 0.4595,
    "y": 0.0771
  },
  "/relics/floral-trinity/02-side.png": {
    "x": 0.4677,
    "y": 0.076
  },
  "/relics/floral-trinity/03-back.png": {
    "x": 0.536,
    "y": 0.0771
  },
  "/relics/floral-trinity/04-side.png": {
    "x": 0.5254,
    "y": 0.0781
  },
  "/relics/floral-trinity/05-side.png": {
    "x": 0.5245,
    "y": 0.0792
  },
  "/relics/sea-mutant/01-front.png": {
    "x": 0.467,
    "y": 0.0729
  },
  "/relics/sea-mutant/02-front.png": {
    "x": 0.5035,
    "y": 0.0792
  },
  "/relics/sea-mutant/03-front.png": {
    "x": 0.4691,
    "y": 0.076
  },
  "/relics/sea-mutant/04-back.png": {
    "x": 0.3928,
    "y": 0.0729
  },
  "/relics/sea-mutant/05-side.png": {
    "x": 0.398,
    "y": 0.0729
  },
  "/relics/sea-mutant/06-side.png": {
    "x": 0.4103,
    "y": 0.0729
  },
  "/relics/fiery-worm/01-side.png": { "x": 0.4952, "y": 0.0847 },
  "/relics/fiery-worm/02-front.png": { "x": 0.481, "y": 0.0847 },
  "/relics/fiery-worm/03-front.png": { "x": 0.4944, "y": 0.0847 },
  "/relics/fiery-worm/04-side.png": { "x": 0.5706, "y": 0.0847 },
  "/relics/fiery-worm/05-back.png": { "x": 0.5015, "y": 0.0837 },
  "/relics/crimson-oracle/01-front.png": { "x": 0.4612, "y": 0.0837 },
  "/relics/crimson-oracle/02-front.png": { "x": 0.4643, "y": 0.0857 },
  "/relics/crimson-oracle/03-side.png": { "x": 0.4695, "y": 0.0847 },
  "/relics/crimson-oracle/04-side.png": { "x": 0.5608, "y": 0.0857 },
  "/relics/crimson-oracle/05-back.png": { "x": 0.5433, "y": 0.0847 },
  "/relics/blue-scarab/01-front.png": { "x": 0.5459, "y": 0.0847 },
  "/relics/blue-scarab/02-side.png": { "x": 0.5455, "y": 0.0847 },
  "/relics/blue-scarab/03-back.png": { "x": 0.4668, "y": 0.0847 },
  "/relics/blue-scarab/04-side.png": { "x": 0.4564, "y": 0.0837 }
};
